import { initializeApp } from 'https://www.gstatic.com/firebasejs/11.7.1/firebase-app.js';
import { getAuth, onAuthStateChanged, signInWithEmailAndPassword, createUserWithEmailAndPassword, GoogleAuthProvider, signInWithPopup, RecaptchaVerifier, signInWithPhoneNumber, signOut } from 'https://www.gstatic.com/firebasejs/11.7.1/firebase-auth.js';
import { firebaseConfig } from './firebase-config.js';
import { API_BASE_URL } from './app-config.js';

const $=s=>document.querySelector(s);
const loginView=$('#loginView'), dashboardView=$('#dashboardView');
let auth, currentUser=null, confirmationResult=null, sites=[];

function esc(x){return String(x??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));}
function msg(t){$('#authMsg').textContent=t||'';}
async function api(url,opts={}){
  const token=currentUser?await currentUser.getIdToken(true):null;
  const headers=new Headers(opts.headers||{}); if(token) headers.set('Authorization','Bearer '+token);
  const target=(API_BASE_URL||'').replace(/\/$/,'')+url; const r=await fetch(target,{...opts,headers}); const data=await r.json().catch(()=>({})); if(!r.ok) throw new Error(data.error||`Request failed (${r.status})`); return data;
}
function render(){
  $('#creditCount').textContent=Math.max(0,10-sites.length); $('#siteCount').textContent=sites.length;
  $('#hello').textContent=`Welcome, ${currentUser?.displayName||currentUser?.email||'Creator'}`;
  const box=$('#sites'); box.innerHTML='';
  if(!sites.length){box.innerHTML='<div class="site"><b>No websites yet</b><p class="muted">Deploy your first ZIP and it will appear here.</p></div>';return;}
  sites.forEach(s=>{const el=document.createElement('div');el.className='site';el.innerHTML=`<div class="site-top"><span class="site-name">${esc(s.name)}</span><span class="badge">${esc(s.status||'LIVE').toUpperCase()}</span></div><div class="url">${esc(s.url)}</div><div class="site-actions"><button data-edit="${s.id}">Edit</button><button data-open="${s.id}">Open</button><button class="danger" data-del="${s.id}">Delete</button></div>`;box.appendChild(el);});
}
function showDash(){loginView.classList.add('hidden');dashboardView.classList.remove('hidden');loadSites();}
async function loadSites(){try{const d=await api('/api/sites');sites=d.sites||[];render();}catch(e){alert(e.message);}}
function openModal(id){$(id).classList.remove('hidden');} function closeModals(){document.querySelectorAll('.modal').forEach(x=>x.classList.add('hidden'));}

document.querySelectorAll('.tab').forEach(b=>b.onclick=()=>{document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));b.classList.add('active');$('#emailAuth').classList.toggle('hidden',b.dataset.auth!=='email');$('#phoneAuth').classList.toggle('hidden',b.dataset.auth!=='phone');});
$('#menuBtn').onclick=async()=>{openModal('#settingsModal'); try{const s=await api('/api/admin/stats'); $('#adminBtn').classList.remove('hidden'); $('#adminStats').textContent=`Users: ${s.users} • Sites: ${s.sites} • Live: ${s.live}`;}catch{$('#adminBtn').classList.add('hidden');}};
$('#deployBtn').onclick=()=>sites.length<10?openModal('#deployModal'):alert('No credits available. Delete an active site to restore one credit.');
document.querySelectorAll('[data-close]').forEach(b=>b.onclick=closeModals); $('#refreshBtn').onclick=loadSites;
$('#logoutBtn').onclick=()=>signOut(auth);
$('#themeBtn').onclick=()=>document.body.classList.toggle('light');
$('#adminBtn').onclick=()=>openModal('#adminModal');

async function emailAuth(){const e=$('#email').value.trim(),p=$('#password').value;if(!e||p.length<6)return msg('Enter a valid email and password (6+ characters).');msg('Signing in…');try{try{await signInWithEmailAndPassword(auth,e,p);}catch(err){if(err.code==='auth/user-not-found'||err.code==='auth/invalid-credential')await createUserWithEmailAndPassword(auth,e,p);else throw err;}msg('');}catch(e){msg(e.message);}}
$('#emailLogin').onclick=emailAuth;
$('#googleLogin').onclick=async()=>{try{await signInWithPopup(auth,new GoogleAuthProvider());}catch(e){msg(e.message);}};
$('#sendOtp').onclick=async()=>{try{if(!window.recaptchaVerifier)window.recaptchaVerifier=new RecaptchaVerifier(auth,'recaptcha-container',{size:'invisible'});confirmationResult=await signInWithPhoneNumber(auth,$('#phone').value.trim(),window.recaptchaVerifier);$('#otp').classList.remove('hidden');$('#verifyOtp').classList.remove('hidden');msg('OTP sent.');}catch(e){msg(e.message);try{window.recaptchaVerifier?.clear();window.recaptchaVerifier=null;}catch{}}};
$('#verifyOtp').onclick=async()=>{try{await confirmationResult.confirm($('#otp').value.trim());msg('');}catch(e){msg('Invalid OTP.');}};

$('#deployNow').onclick=async()=>{
  const f=$('#zipFile').files[0],name=$('#siteName').value.trim(),tld=$('#domainTld').value;
  if(!f)return alert('Select a ZIP file.'); if(f.size>25*1024*1024)return alert('Maximum upload size is 25 MB.');
  $('#uploadStatus').textContent='Uploading to Cloudinary and deploying…'; $('#deployNow').disabled=true;
  try{const fd=new FormData();fd.append('project',f,f.name);fd.append('name',name);fd.append('tld',tld);const d=await api('/api/deploy',{method:'POST',body:fd});closeModals();sites.unshift(d.site);render();$('#siteName').value='';$('#zipFile').value='';$('#uploadStatus').textContent='Ready';}catch(e){alert(e.message);$('#uploadStatus').textContent='Deployment failed';}finally{$('#deployNow').disabled=false;}
};
$('#sites').onclick=async e=>{const d=e.target.dataset;if(d.open){const s=sites.find(x=>x.id===d.open);if(s)window.open(s.url,'_blank');}
 if(d.del){if(!confirm('Delete this deployment? Its 1 credit will be restored.'))return;try{await api('/api/sites/'+d.del,{method:'DELETE'});await loadSites();}catch(e){alert(e.message);}}
 if(d.edit){const s=sites.find(x=>x.id===d.edit);if(!s)return;const n=prompt('New website name',s.name);if(!n)return;try{await api('/api/sites/'+s.id,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:n,tld:s.tld})});await loadSites();}catch(e){alert(e.message);}}};

async function loadAdmin(){try{const [st,list]=await Promise.all([api('/api/admin/stats'),api('/api/admin/sites')]);$('#adminStatsFull').textContent=`${st.users} users • ${st.sites} sites • ${st.live} live`;const b=$('#adminSites');b.innerHTML=(list.sites||[]).map(s=>`<div class="site"><b>${esc(s.name)}</b><div class="url">${esc(s.url)}</div><button class="danger" data-admin-del="${s.id}">Delete</button></div>`).join('')||'<p class="muted">No sites.</p>';}catch(e){alert(e.message);}}
$('#adminModal').addEventListener('click',async e=>{const id=e.target.dataset.adminDel;if(!id)return;if(!confirm('Admin delete this site?'))return;try{await api('/api/admin/sites/'+id,{method:'DELETE'});loadAdmin();loadSites();}catch(x){alert(x.message);}});
$('#adminBtn').addEventListener('click',loadAdmin);

try{const app=initializeApp(firebaseConfig);auth=getAuth(app);onAuthStateChanged(auth,u=>{currentUser=u;if(u)showDash();else{dashboardView.classList.add('hidden');loginView.classList.remove('hidden');}});}catch(e){msg('Firebase configuration is missing or invalid. Edit firebase-config.js.');}

// Native WebGL2 animated background.
const canvas=document.createElement('canvas');canvas.id='webglCanvas';canvas.style.cssText='position:fixed;inset:0;z-index:-2;width:100%;height:100%;opacity:.18;pointer-events:none';document.body.appendChild(canvas);const gl=canvas.getContext('webgl2');
if(gl){const vs=`#version 300 es\nin vec2 p;out vec2 uv;void main(){uv=p*.5+.5;gl_Position=vec4(p,0.,1.);}`,fs=`#version 300 es\nprecision highp float;in vec2 uv;out vec4 o;uniform float t;void main(){vec2 p=uv*2.-1.;p.x*=1.6;float a=sin(length(p)*7.-t*2.)*.08;float b=sin(p.x*5.+t)*.04;float glow=.12/(.15+abs(length(p)-.55+a+b));vec3 c=vec3(.18,.25,.9)*glow+vec3(.01,.02,.07);o=vec4(c,1.);}`;function sh(type,src){const s=gl.createShader(type);gl.shaderSource(s,src);gl.compileShader(s);return s}const pr=gl.createProgram();gl.attachShader(pr,sh(gl.VERTEX_SHADER,vs));gl.attachShader(pr,sh(gl.FRAGMENT_SHADER,fs));gl.linkProgram(pr);const buf=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,buf);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,1,1]),gl.STATIC_DRAW);const loc=gl.getAttribLocation(pr,'p'),timeLoc=gl.getUniformLocation(pr,'t');function resize(){const d=devicePixelRatio||1,w=innerWidth*d,h=innerHeight*d;if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h;gl.viewport(0,0,w,h)}}function loop(t){resize();gl.useProgram(pr);gl.enableVertexAttribArray(loc);gl.bindBuffer(gl.ARRAY_BUFFER,buf);gl.vertexAttribPointer(loc,2,gl.FLOAT,false,0,0);gl.uniform1f(timeLoc,t*.001);gl.drawArrays(gl.TRIANGLE_STRIP,0,4);requestAnimationFrame(loop)}requestAnimationFrame(loop);}
