// Copy to firebase-config.js and fill your Firebase Web App config.
// Do NOT put service-account/private keys here.
export const firebaseConfig = {
  apiKey: "AIzaSyCC7xaarBaxmKmT-YbfpBv-yFO7vx9tFnw",
  authDomain: "vupload-838c5.firebaseapp.com",
  projectId: "vupload-838c5",
  storageBucket: "vupload-838c5.firebasestorage.app",
  messagingSenderId: "1034370493063",
  appId: "1:1034370493063:web:74d8b24df614916c9ce622"
};
