// Browser-safe Cloudinary config.
// Use an UNSIGNED upload preset. Never expose API_SECRET in frontend code.
export const cloudinaryConfig={
 cloudName:"hcbsjrma",
 uploadPreset:"upload"
};
