// Leave empty when frontend and backend share the same origin.
// For a separate static frontend, set this to your backend origin, e.g. https://api.example.com
export const API_BASE_URL = "https://ownhostplatform.edgeone.dev";
