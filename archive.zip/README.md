# OwnHost — Full-stack static hosting platform

This version is an actual deployable full-stack app. It is designed for a VPS/container where Node.js can persist a `data/` volume.

## What is real
- Firebase Authentication is verified server-side with Firebase Admin.
- Firestore stores deployments, ownership, status and URLs.
- Cloudinary stores the original uploaded ZIP as a raw resource.
- The server safely extracts the ZIP to its persistent `data/sites/<id>` directory and serves the deployed website.
- Users get 10 active deployment slots; deleting restores one.
- Rename/edit and delete are authenticated and ownership-checked.
- Admin dashboard is protected by `ADMIN_UIDS` or Firebase custom claim `admin=true`.
- Public hosting route: `/sites/<slug><tld>/...`.

## Required setup
1. Create a Firebase project and enable Email/Password, Google and/or Phone Authentication.
2. Create a Firestore database.
3. Create a Firebase Web App and put its client config in `firebase-config.js`.
4. Create a Firebase service account. Put the JSON in the server environment variable `FIREBASE_SERVICE_ACCOUNT_JSON`.
5. Create a Cloudinary account and set `CLOUDINARY_CLOUD_NAME`, `CLOUDINARY_API_KEY`, `CLOUDINARY_API_SECRET`.
6. Set `ADMIN_UIDS` to the Firebase UID(s) of your administrators.
7. Set `PUBLIC_BASE_URL` to the public HTTPS origin where this Node app is reachable.
8. Install and run: `cd backend && npm install && npm start`.

## Important production deployment
Use a VPS/container with persistent storage. Mount `/app/data` (or `DATA_DIR`) to a persistent volume; otherwise deployed sites disappear when the container is replaced.

Put Nginx/Caddy/Cloudflare in front for TLS. The included public route is a reliable fallback format such as:
`https://host.example.com/sites/my-site.site/`

### Wildcard subdomains
The app currently exposes deployment URLs under `/sites/...` because a wildcard domain needs DNS/reverse-proxy configuration. To use `https://my-site.host.example.com/`, configure a wildcard DNS record (`*.host.example.com`) and a proxy that forwards the Host header, then adapt the public route to resolve `req.hostname` to `domainKey`.

## Security
- ZIP traversal is blocked.
- Uploads are limited by `MAX_UPLOAD_MB`.
- Auth tokens are verified server-side.
- Users can only edit/delete their own sites.
- Admin routes require an allowlisted UID or admin claim.
- Do not commit Firebase service-account JSON, Cloudinary API secret, or `.env` to Git.

## Firebase rules
A minimal Firestore rules baseline is included in `firestore.rules`. The server uses Firebase Admin, so server-side authorization remains authoritative for this application.
