import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import multer from 'multer';
import unzipper from 'unzipper';
import fs from 'fs';
import fsp from 'fs/promises';
import path from 'path';
import crypto from 'crypto';
import { Readable } from 'stream';
import { pipeline } from 'stream/promises';
import admin from 'firebase-admin';
import { v2 as cloudinary } from 'cloudinary';

const app = express();
const PORT = Number(process.env.PORT || 8787);
const HOST = process.env.HOST || '0.0.0.0';
const DATA_DIR = path.resolve(process.env.DATA_DIR || './data');
const SITES_DIR = path.join(DATA_DIR, 'sites');
const MAX_UPLOAD_MB = Number(process.env.MAX_UPLOAD_MB || 25);
const PUBLIC_BASE_URL = (process.env.PUBLIC_BASE_URL || `http://localhost:${PORT}`).replace(/\/$/, '');
const PUBLIC_DIR = path.resolve(path.dirname(new URL(import.meta.url).pathname), '../public');
const ALLOWED_TLDS = new Set(['.com','.io','.free.io','.ia','.site']);
const RESERVED = new Set(['admin','api','www','mail','ftp','app','dashboard','assets']);

await fsp.mkdir(SITES_DIR, { recursive: true });

function env(name, required=true){ const v=process.env[name]; if(required && !v) throw new Error(`Missing ${name}`); return v; }

// Firebase Admin: set FIREBASE_SERVICE_ACCOUNT_JSON to the downloaded service-account JSON string.
let firebaseReady = false;
try {
  if (process.env.FIREBASE_SERVICE_ACCOUNT_JSON) {
    admin.initializeApp({ credential: admin.credential.cert(JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON)) });
    firebaseReady = true;
  }
} catch (e) { console.error('Firebase init failed:', e.message); }
const firestore = () => firebaseReady ? admin.firestore() : null;

if (process.env.CLOUDINARY_CLOUD_NAME && process.env.CLOUDINARY_API_KEY && process.env.CLOUDINARY_API_SECRET) {
  cloudinary.config({
    cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
    api_key: process.env.CLOUDINARY_API_KEY,
    api_secret: process.env.CLOUDINARY_API_SECRET,
    secure: true
  });
}
const cloudinaryReady = !!(process.env.CLOUDINARY_CLOUD_NAME && process.env.CLOUDINARY_API_KEY && process.env.CLOUDINARY_API_SECRET);

app.set('trust proxy', 1);
app.use(helmet({ crossOriginResourcePolicy: false }));
app.use(cors({ origin: true, credentials: false }));
app.use(express.json({ limit: '256kb' }));
app.use('/api', rateLimit({ windowMs: 60_000, limit: 120, standardHeaders: true, legacyHeaders: false }));
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: MAX_UPLOAD_MB * 1024 * 1024, files: 1 } });

function slugify(v){ return String(v||'').toLowerCase().trim().replace(/[^a-z0-9-]+/g,'-').replace(/^-+|-+$/g,'').slice(0,48); }
function siteDir(id){ return path.join(SITES_DIR, id); }
function safeJoin(root, rel){
  const p = path.resolve(root, rel);
  if (p !== root && !p.startsWith(root + path.sep)) throw new Error('Unsafe path');
  return p;
}
function publicUrl(site){ return `${PUBLIC_BASE_URL}/sites/${encodeURIComponent(site.slug)}${site.tld || ''}/`; }
function normalizeTld(tld){ const x=String(tld||'.site').toLowerCase(); return ALLOWED_TLDS.has(x) ? x : '.site'; }
function domainKey(slug,tld){ return `${slug}${tld}`.replace(/^\./,''); }
function isHtmlPath(p){ return /\.(html?|xhtml)$/i.test(p); }
function contentType(p){ const m={'.html':'text/html; charset=utf-8','.htm':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.gif':'image/gif','.webp':'image/webp','.ico':'image/x-icon','.txt':'text/plain; charset=utf-8','.wasm':'application/wasm','.mp3':'audio/mpeg','.mp4':'video/mp4','.webm':'video/webm'}; return m[path.extname(p).toLowerCase()] || 'application/octet-stream'; }

async function requireAuth(req,res,next){
  try {
    if(!firebaseReady) return res.status(503).json({error:'Firebase Admin is not configured on the server.'});
    const h=req.headers.authorization||'';
    if(!h.startsWith('Bearer ')) return res.status(401).json({error:'Missing Firebase ID token'});
    req.user=await admin.auth().verifyIdToken(h.slice(7), true);
    next();
  } catch(e){ return res.status(401).json({error:'Invalid or expired authentication token'}); }
}
function requireAdmin(req,res,next){
  const admins=(process.env.ADMIN_UIDS||'').split(',').map(x=>x.trim()).filter(Boolean);
  if(!admins.includes(req.user.uid) && req.user.admin !== true) return res.status(403).json({error:'Admin access required'});
  next();
}
async function userSites(uid){
  const db=firestore(); if(!db) return [];
  const snap=await db.collection('sites').where('ownerUid','==',uid).get();
  return snap.docs.map(d=>({id:d.id,...d.data()})).sort((a,b)=>String(b.createdAt?.toDate?.()||b.createdAt||'').localeCompare(String(a.createdAt?.toDate?.()||a.createdAt||'')));
}
async function getSite(id){ const db=firestore(); if(!db) return null; const d=await db.collection('sites').doc(id).get(); return d.exists?{id:d.id,...d.data()}:null; }
async function assertUniqueSlug(slug,tld,excludeId=null){
  const db=firestore(); if(!db) return;
  const snap=await db.collection('sites').where('domainKey','==',domainKey(slug,tld)).limit(2).get();
  if(snap.docs.some(d=>d.id!==excludeId)) throw new Error('That deployment URL is already in use');
}

app.get('/api/health',(req,res)=>res.json({ok:true,service:'OwnHost',firebase:firebaseReady,cloudinary:cloudinaryReady,publicBaseUrl:PUBLIC_BASE_URL}));

app.post('/api/deploy', requireAuth, upload.single('project'), async (req,res)=>{
  try{
    if(!req.file) return res.status(400).json({error:'ZIP project file is required'});
    if(!/\.zip$/i.test(req.file.originalname)) return res.status(400).json({error:'Only .zip files are accepted'});
    const name=slugify(req.body.name)||'my-site'; const tld=normalizeTld(req.body.tld);
    if(RESERVED.has(name)) return res.status(400).json({error:'Reserved site name'});
    const sites=await userSites(req.user.uid);
    if(sites.length>=10) return res.status(403).json({error:'No deployment credits. Delete a site to restore one credit.'});
    await assertUniqueSlug(name,tld);
    if(!firebaseReady) return res.status(503).json({error:'Firebase Admin is required for deployments'});
    if(!cloudinaryReady) return res.status(503).json({error:'Cloudinary is required for deployments'});

    const id=crypto.randomUUID(); const root=siteDir(id); await fsp.mkdir(root,{recursive:true});
    // Store source ZIP in Cloudinary as a raw resource for backup/audit.
    const uploadResult=await new Promise((resolve,reject)=>{
      const stream=cloudinary.uploader.upload_stream({resource_type:'raw',folder:'ownhost/projects',public_id:id,overwrite:true},(err,result)=>err?reject(err):resolve(result));
      Readable.from(req.file.buffer).pipe(stream);
    });

    // Extract safely. Reject absolute paths and traversal attempts.
    const directory=await unzipper.Open.buffer(req.file.buffer);
    for(const entry of directory.files){
      const rel=entry.path.replace(/\\/g,'/');
      if(!rel || rel.endsWith('/')) continue;
      if(rel.startsWith('/') || rel.includes('..') || /^[A-Za-z]:/.test(rel)) throw new Error('Unsafe ZIP path detected');
      const dest=safeJoin(root,rel); await fsp.mkdir(path.dirname(dest),{recursive:true});
      await pipeline(entry.stream(),fs.createWriteStream(dest));
    }
    const top=await fsp.readdir(root,{withFileTypes:true});
    if(top.length===0) throw new Error('ZIP is empty');
    const hasIndex=top.some(x=>x.isFile()&&x.name.toLowerCase()==='index.html');
    const site={id,name,tld,slug:name,domainKey:domainKey(name,tld),ownerUid:req.user.uid,ownerEmail:req.user.email||null,status:'live',sourceCloudinaryId:uploadResult.public_id,sourceCloudinaryUrl:uploadResult.secure_url||null,createdAt:admin.firestore.FieldValue.serverTimestamp(),updatedAt:admin.firestore.FieldValue.serverTimestamp(),hasIndex,url:publicUrl({slug:name,tld})};
    await firestore().collection('sites').doc(id).set(site);
    const saved=await getSite(id);
    res.status(201).json({site:saved,credits:10-sites.length-1});
  }catch(e){ console.error(e); return res.status(400).json({error:e.message||'Deployment failed'}); }
});

app.get('/api/sites',requireAuth,async(req,res)=>{ try{ const sites=await userSites(req.user.uid); res.json({sites,credits:Math.max(0,10-sites.length)}); }catch(e){res.status(500).json({error:e.message});} });

app.patch('/api/sites/:id',requireAuth,async(req,res)=>{
  try{ const site=await getSite(req.params.id); if(!site) return res.status(404).json({error:'Site not found'}); if(site.ownerUid!==req.user.uid) return res.status(403).json({error:'Not your site'});
    const name=slugify(req.body.name)||site.slug; const tld=normalizeTld(req.body.tld||site.tld); if(RESERVED.has(name)) return res.status(400).json({error:'Reserved site name'}); await assertUniqueSlug(name,tld,site.id);
    await firestore().collection('sites').doc(site.id).update({name,slug:name,tld,domainKey:domainKey(name,tld),url:publicUrl({slug:name,tld}),updatedAt:admin.firestore.FieldValue.serverTimestamp()});
    res.json({site:await getSite(site.id)});
  }catch(e){res.status(400).json({error:e.message});}
});

app.delete('/api/sites/:id',requireAuth,async(req,res)=>{
  try{ const site=await getSite(req.params.id); if(!site) return res.status(404).json({error:'Site not found'}); if(site.ownerUid!==req.user.uid && !((process.env.ADMIN_UIDS||'').split(',').includes(req.user.uid))) return res.status(403).json({error:'Not allowed'});
    await fsp.rm(siteDir(site.id),{recursive:true,force:true});
    if(cloudinaryReady && site.sourceCloudinaryId){ try{ await cloudinary.uploader.destroy(site.sourceCloudinaryId,{resource_type:'raw'}); }catch(e){console.warn('Cloudinary cleanup:',e.message);} }
    await firestore().collection('sites').doc(site.id).delete();
    const remaining=await userSites(req.user.uid); res.json({ok:true,credits:10-remaining.length});
  }catch(e){res.status(500).json({error:e.message});}
});

app.get('/api/admin/stats',requireAuth,requireAdmin,async(req,res)=>{
  const db=firestore(); if(!db) return res.status(503).json({error:'Firebase not configured'});
  const [users,sites]=await Promise.all([admin.auth().listUsers(1000),db.collection('sites').get()]);
  res.json({users:users.users.length,sites:sites.size,live:sites.docs.filter(d=>d.data().status==='live').length});
});
app.get('/api/admin/sites',requireAuth,requireAdmin,async(req,res)=>{ const db=firestore(); const snap=await db.collection('sites').limit(500).get(); res.json({sites:snap.docs.map(d=>({id:d.id,...d.data()}))}); });
app.delete('/api/admin/sites/:id',requireAuth,requireAdmin,async(req,res)=>{ req.user={...req.user}; const fake={uid:req.user.uid}; const site=await getSite(req.params.id); if(!site) return res.status(404).json({error:'Not found'}); await fsp.rm(siteDir(site.id),{recursive:true,force:true}); if(cloudinaryReady&&site.sourceCloudinaryId){try{await cloudinary.uploader.destroy(site.sourceCloudinaryId,{resource_type:'raw'});}catch{}} await firestore().collection('sites').doc(site.id).delete(); res.json({ok:true}); });

// Public static hosting. URL: /sites/<slug><tld>/path. Example /sites/my-site.site/
app.get('/sites/:host/*', async(req,res)=>{
  try{
    const host=req.params.host; const db=firestore(); if(!db) return res.status(503).send('Hosting database unavailable');
    const snap=await db.collection('sites').where('domainKey','==',host).limit(1).get();
    if(snap.empty) return res.status(404).send('Site not found');
    const site={id:snap.docs[0].id,...snap.docs[0].data()}; const requested=req.params[0]||''; let rel=requested || 'index.html';
    rel=decodeURIComponent(rel).replace(/^\/+/, ''); if(rel==='') rel='index.html';
    let file=safeJoin(siteDir(site.id),rel);
    try{ const st=await fsp.stat(file); if(st.isDirectory()) file=safeJoin(file,'index.html'); }catch{}
    if(!fs.existsSync(file)){ if(!path.extname(rel)) file=safeJoin(siteDir(site.id),'index.html'); else return res.status(404).send('File not found'); }
    res.setHeader('Content-Type',contentType(file)); res.setHeader('X-Content-Type-Options','nosniff'); res.setHeader('Cache-Control','public, max-age=60'); res.sendFile(file);
  }catch(e){ console.error(e); res.status(400).send('Invalid request'); }
});

app.use(express.static(PUBLIC_DIR));
app.get('*',(req,res)=>res.sendFile(path.join(PUBLIC_DIR,'index.html')));
app.listen(PORT,HOST,()=>console.log(`OwnHost running on ${PUBLIC_BASE_URL}`));
